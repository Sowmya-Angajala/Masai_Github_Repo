import React from 'react';
import ColorToggleButton from './togglecomponent';

function App() {
  return (
    <div className="App">
      <ColorToggleButton />
    </div>
  );
}

export default App;
